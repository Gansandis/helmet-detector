# Helmet Detector (Local) - ตรวจรถก่อน แล้วตรวจหมวก

1. ติดตั้ง Python 3.9+
2. pip install -r requirements.txt
3. ดาวน์โหลดไฟล์โมเดล best.pt (ปุ่มบนหน้าเว็บ) มาวางไว้ในโฟลเดอร์นี้
4. รัน: python helmet_detect.py --source 0   (กด q เพื่อออก)

ครั้งแรกโปรแกรมจะโหลด yolov8n.pt (โมเดลจับรถ) อัตโนมัติ ต้องต่ออินเทอร์เน็ต
