"""
ระบบตรวจจับหมวกกันน็อก 2 ขั้น
  ขั้นที่ 1: หารถมอเตอร์ไซค์และคน (โมเดลสำเร็จรูป yolov8n.pt ไม่ต้องเทรน)
  ขั้นที่ 2: ตัดภาพคนขับ แล้วตรวจหมวกด้วยโมเดลที่เทรนเอง (best.pt)

ติดตั้ง:  pip install ultralytics opencv-python
ใช้งาน:   python helmet_detect.py --source 0          (เว็บแคม)
          python helmet_detect.py --source video.mp4
          python helmet_detect.py --weights best.pt --conf 0.5
"""
import argparse
import time

import cv2
from ultralytics import YOLO

parser = argparse.ArgumentParser()
parser.add_argument("--weights", default="best.pt")
parser.add_argument("--source", default="0")
parser.add_argument("--conf", type=float, default=0.5)
args = parser.parse_args()

veh_model = YOLO("yolov8n.pt")     # COCO: person=0, motorcycle=3
helmet_model = YOLO(args.weights)  # คลาส "helmet detect" / "helmet not detect"
NO_HELMET = "helmet not detect"

source = int(args.source) if args.source.isdigit() else args.source
cap = cv2.VideoCapture(source)
last_alert = 0


def overlap_of_a(a, b):
    """สัดส่วนพื้นที่ของกรอบ a ที่ซ้อนกับกรอบ b"""
    w = min(a[2], b[2]) - max(a[0], b[0])
    h = min(a[3], b[3]) - max(a[1], b[1])
    return max(0, w) * max(0, h) / max(1, (a[2] - a[0]) * (a[3] - a[1]))


def box(img, b, color, label):
    x1, y1, x2, y2 = map(int, b)
    cv2.rectangle(img, (x1, y1), (x2, y2), color, 2)
    cv2.putText(img, label, (x1, max(16, y1 - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)


while cap.isOpened():
    ok, frame = cap.read()
    if not ok:
        break
    H, W = frame.shape[:2]

    # ขั้นที่ 1: หารถมอเตอร์ไซค์ + คน
    r = veh_model(frame, conf=0.4, classes=[0, 3], verbose=False)[0]
    bikes = [b.xyxy[0].tolist() for b in r.boxes if int(b.cls) == 3]
    persons = [b.xyxy[0].tolist() for b in r.boxes if int(b.cls) == 0]
    for b in bikes:
        box(frame, b, (255, 120, 0), "motorcycle")

    violations = 0
    for p in persons:
        # คนที่ซ้อนทับกับมอเตอร์ไซค์ถือว่าเป็นผู้ขับขี่/ผู้ซ้อน
        if not any(overlap_of_a(p, b) > 0.25 for b in bikes):
            continue

        # ขั้นที่ 2: ตัดภาพคนขับ (ขยายขอบเล็กน้อย) แล้วตรวจหมวก
        pw, ph = (p[2] - p[0]) * 0.1, (p[3] - p[1]) * 0.1
        x1, y1 = max(0, int(p[0] - pw)), max(0, int(p[1] - ph))
        x2, y2 = min(W, int(p[2] + pw)), min(H, int(p[3] + ph))
        if x2 - x1 < 24 or y2 - y1 < 24:
            continue
        hr = helmet_model(frame[y1:y2, x1:x2], conf=args.conf, verbose=False)[0]
        if len(hr.boxes) == 0:
            box(frame, p, (150, 150, 150), "unknown")
            continue
        best = max(hr.boxes, key=lambda b: float(b.conf))
        name = helmet_model.names[int(best.cls)]
        if name == NO_HELMET:
            violations += 1
            box(frame, p, (0, 0, 255), "NO HELMET")
        else:
            box(frame, p, (0, 200, 0), "helmet")

    if violations and time.time() - last_alert > 5:
        last_alert = time.time()
        fname = f"violation_{int(last_alert)}.jpg"
        cv2.imwrite(fname, frame)
        print(f"[แจ้งเตือน] พบผู้ขับขี่ไม่สวมหมวก {violations} คน -> {fname}")

    cv2.imshow("Helmet Detection", frame)
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
